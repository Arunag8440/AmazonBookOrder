﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Remote;
using System.Threading;
using System.Collections.Generic;

namespace AmazonBookCheckout
{
    [TestClass]
    public class UnitTest1
    {
    
        private const string URL = "https://www.amazon.in";

        private const string CHROME_DRIVER_PATH = @"D:\SelWebDrivers\chromedriver_win32\";
        ChromeDriver driver;
        [TestInitialize]
        //Navigate to Amazon Website
        public void InitializeDriver()
        {
            driver= new ChromeDriver(CHROME_DRIVER_PATH);
            driver.Navigate();

        }

        [TestMethod]
        //Verify if Amazon Website Loaded Properly
        public void TestMethod1()
        {
            driver.FindElementByPartialLinkText("Amazon");

        }

        [TestMethod]
        //Search Book and add it to Basket
        public void TestMethod2()
        {
            //Click on Shop by category Link
            driver.FindElementByLinkText("Shop byCategory").Click();
            //Wait for next page to load
            Thread.Sleep(5000);
            //Click on All Books Link
            driver.FindElementByLinkText("All Books").Click();
            //Wait for next page to load
            Thread.Sleep(5000);
            //Find the Search box and enter game of thrones
            driver.FindElementById("twotabsearchtextbox").SendKeys("Game of Thrones");
            //Hit enter to Search
            SendKeys.Send("{ENTER}");
            //Wait for Search Results to Load
            Thread.Sleep(5000);
            //Get the List of Results
            var resultList= driver.FindElementById("s-results-list-atf").FindElement(By.Id("result_0"));
            //Check if the first item contains the required title
            if (resultList.Text.Contains("A Game of Thrones(A Song of Ice and Fire, Book 1)"))
                {
                    //Click on the Book Link and go to details
                    driver.FindElementByPartialLinkText("A Game of Thrones(A Song of Ice and Fire, Book 1)").Click();
                     //Wait for Search Results to Load
                    Thread.Sleep(5000);
                    //Navigate to the Details Window
                    IList<string> tabs = new List<string>(driver.WindowHandles);
                    driver.SwitchTo().Window(tabs[1]);
                    IJavaScriptExecutor jscript = driver as IJavaScriptExecutor;
                    jscript.ExecuteScript("alert('Focus')");
                    driver.SwitchTo().Alert().Accept();

                //Click on  Add to Cart 
                 driver.FindElementById("add-to-cart-button").Click();
            }
        }
    }
}
